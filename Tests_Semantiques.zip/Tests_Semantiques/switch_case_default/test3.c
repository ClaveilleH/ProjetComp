extern int printd(int i);

int main() {
   int i,j;
   i=3;
   default : printd(i);
   
}
