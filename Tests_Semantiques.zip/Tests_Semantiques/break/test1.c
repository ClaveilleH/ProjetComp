extern int printd( int i );

int main() {
   int i = 0;
   if (i == 0) break;
}
