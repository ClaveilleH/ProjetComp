extern int printd( int i );

int main() {
    int i;
    switch(i) {
        if (1==1) {
        }
    }
    break;
}