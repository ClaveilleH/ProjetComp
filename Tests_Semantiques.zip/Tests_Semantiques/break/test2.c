extern int printd( int i );

int main() {
    int i;
    i = 0;
    while (i == 0) {
        if (i == 0) {
            break;
        }
        else {
            break;
        }
    }
    if (i==i) break;
}