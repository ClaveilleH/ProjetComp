extern int printd( int i );

int main() {
    int i;
    switch(i) {
        break;
        case 1:
            break;
    }
    {{break;}}
}