extern int printd( int i );

int main() {
    {
        break;
    }
}