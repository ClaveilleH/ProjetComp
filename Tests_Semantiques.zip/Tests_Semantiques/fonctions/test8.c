extern int printd( int i );

int intfonc() {
  int j;
}

int main() {
  return 0;
}
