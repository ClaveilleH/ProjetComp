extern int printd( int i );
extern void pushing();

void push() {
  return;
}

int main() {
  int j, k;
  j = push();
  k = pushing();
  return 0;
}
