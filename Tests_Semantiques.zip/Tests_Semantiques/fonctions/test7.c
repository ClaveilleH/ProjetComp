extern int printd( int i );
extern void pushing();

void pushing() {
  return;
}

int main() {
  return 0;
}
