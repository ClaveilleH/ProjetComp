/* TEST VARIABLES MINIC */

int a;
int main() {
  int a, a;
  a = 0;
}
