extern int printd( int i );

int main() {
  int i;
  i = 0;
  for ( i = -10; i <= 10; i = i+1 ) {
    int j;
    j = j + 1;
    printd(i);
  }
  return 0;
}
