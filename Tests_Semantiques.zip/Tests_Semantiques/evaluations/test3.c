int i, j;

/* On peut compiler même si il y a pas de fonctions */