void func() {

}

int a;

/* On ne peut pas faire de declarations après les fonctions */