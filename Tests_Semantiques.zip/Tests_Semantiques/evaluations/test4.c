void i, j;

/* On peut pas déclarer de variable void */