/* TEST TABLEAUX MINIC */

int tab[300];

int main() {
  int tab;
  tab[3] = tab[200];
  tab[400] = tab[0];
}
