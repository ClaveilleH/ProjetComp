/* TEST TABLEAUX MINIC */

int tab[300];

int main() {
  tab = 5;
}
