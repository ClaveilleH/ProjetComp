/* TEST TABLEAUX MINIC */

int tab[300];

int main() {
  tab[3][4] = tab[200][6];
}
